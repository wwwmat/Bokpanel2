package com.bokpanel.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    SharedPreferences p;
    LinearLayout root;
    int green = Color.rgb(20,160,80);
    @Override public void onCreate(Bundle b) { super.onCreate(b); p=getSharedPreferences("bp",0); show(); }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(35,40,45)); t.setPadding(0,dp(8),0,dp(8)); return t; }
    Button btn(String s,Runnable r){ Button b=new Button(this); b.setText(s); b.setOnClickListener(v->r.run()); return b; }
    void show(){
        ScrollView sc=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(20),dp(20),dp(20),dp(24)); sc.addView(root);
        TextView title=text("Боковая Панель",28); title.setTextColor(green); root.addView(title);
        root.addView(text("Настройка выдвижных панелей и ярлыков приложений",14));
        root.addView(btn("Разрешение отображения поверх окон",()->{
            if(!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,android.net.Uri.parse("package:"+getPackageName())));
            else Toast.makeText(this,"Разрешение уже выдано",Toast.LENGTH_SHORT).show();
        }));
        root.addView(text("Количество панелей: "+p.getInt("count",3),18));
        SeekBar count=seek(1,10,p.getInt("count",3),v->{p.edit().putInt("count",v).apply();}); root.addView(count);
        root.addView(text("Количество столбцов: "+p.getInt("cols",3),18));
        SeekBar cols=seek(1,3,p.getInt("cols",3),v->{p.edit().putInt("cols",v).apply();}); root.addView(cols);
        addSetting("Толщина кнопки активации (%)","handleWidth",1,100,18);
        addSetting("Высота кнопки активации (%)","handleHeight",1,100,28);
        addSetting("Прозрачность кнопки (%)","handleAlpha",0,100,90);
        addSetting("Положение кнопки (%)","handlePosition",0,100,50);
        addSetting("Прозрачность панели (%)","panelAlpha",0,100,95);
        root.addView(text("Цвет кнопки",18)); root.addView(colorChoices("handleColor"));
        root.addView(text("Цвет панели",18)); root.addView(colorChoices("panelColor"));
        root.addView(text("Выбор ярлыков для панели",18));
        for(int i=0;i<p.getInt("count",3);i++){
            final int page=i;
            root.addView(btn("Панель "+(i+1)+" — выбрать приложения",()->pickApps(page)));
        }
        root.addView(btn("Запустить / обновить боковую панель",()->startPanel()));
        root.addView(text("Панели создаются пустыми. Для вызова проведите влево от полоски у правого края экрана.",13));
        setContentView(sc);
    }
    interface Change { void set(int value); }
    SeekBar seek(int min,int max,int value,Change c){ SeekBar s=new SeekBar(this); s.setMax(max-min); s.setProgress(value-min); s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int n,boolean u){if(u)c.set(n+min);} public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}}); return s; }
    void addSetting(String label,String key,int min,int max,int def){
        TextView t=text(label+": "+p.getInt(key,def),16); root.addView(t);
        SeekBar s=seek(min,max,p.getInt(key,def),v->{p.edit().putInt(key,v).apply();t.setText(label+": "+v);}); root.addView(s);
    }
    View colorChoices(String key){
        LinearLayout row=new LinearLayout(this);
        int[] colors={0xff16a34a,0xffe53935,0xff1976d2,0xff20252b,0xff8e24aa,0xffff9800};
        for(int color:colors){ View v=new View(this); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(38),dp(38)); lp.setMargins(0,0,dp(8),0); v.setLayoutParams(lp); android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(8));v.setBackground(d);v.setOnClickListener(w->{p.edit().putInt(key,color).apply();});row.addView(v); }
        return row;
    }
    void pickApps(int page){
        Intent main=new Intent(Intent.ACTION_MAIN,null); main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> apps=getPackageManager().queryIntentActivities(main,0);
        Collections.sort(apps,(a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
        String[] labels=new String[apps.size()]; boolean[] checked=new boolean[apps.size()];
        Set<String> selected=new LinkedHashSet<>(Arrays.asList(p.getString("apps"+page,"").split("\\|")));
        for(int i=0;i<apps.size();i++){labels[i]=apps.get(i).loadLabel(getPackageManager()).toString();checked[i]=selected.contains(apps.get(i).activityInfo.packageName);}
        new AlertDialog.Builder(this).setTitle("Ярлыки панели "+(page+1)).setMultiChoiceItems(labels,checked,(d,w,on)->{String pkg=apps.get(w).activityInfo.packageName;if(on)selected.add(pkg);else selected.remove(pkg);})
          .setPositiveButton("Сохранить",(d,w)->{p.edit().putString("apps"+page,String.join("|",selected)).apply();}).setNegativeButton("Отмена",null).show();
    }
    void startPanel(){
        if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"Сначала разрешите отображение поверх окон",Toast.LENGTH_LONG).show();return;}
        Intent i=new Intent(this,PanelService.class); if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
        Toast.makeText(this,"Панель запускается",Toast.LENGTH_SHORT).show();
    }
    @Override protected void onResume(){super.onResume();}
}
