package com.bokpanel.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class PanelService extends Service {
    WindowManager wm; View handle,panel; WindowManager.LayoutParams handleLp,panelLp;
    float downX,downY; int current=0; SharedPreferences p;
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    int overlayType(){return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;}
    @Override public void onCreate(){super.onCreate();p=getSharedPreferences("bp",0);wm=(WindowManager)getSystemService(WINDOW_SERVICE);showHandle();}
    void showHandle(){
        if(!Settings.canDrawOverlays(this)||handle!=null)return;
        View v=new View(this); handle=v; v.setBackgroundColor(p.getInt("handleColor",0xff16a34a));v.setAlpha(p.getInt("handleAlpha",90)/100f);
        int screenH=getResources().getDisplayMetrics().heightPixels;
        int h=Math.max(dp(8),screenH*p.getInt("handleHeight",28)/100);
        int w=Math.max(dp(2),dp(48)*p.getInt("handleWidth",18)/100);
        handleLp=new WindowManager.LayoutParams(w,h,overlayType(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        handleLp.gravity=Gravity.RIGHT|Gravity.TOP;handleLp.y=Math.max(0,(screenH-h)*p.getInt("handlePosition",50)/100);
        v.setOnTouchListener((view,e)->{if(e.getAction()==0){downX=e.getRawX();downY=e.getRawY();return true;}if(e.getAction()==1){if(e.getRawX()<downX-dp(25))open(0);return true;}return true;});
        wm.addView(v,handleLp);
    }
    void open(int page){
        close(); current=Math.max(0,Math.min(page,p.getInt("count",3)-1));
        int cols=p.getInt("cols",3); LinearLayout outer=new LinearLayout(this);outer.setOrientation(1);outer.setPadding(dp(10),dp(12),dp(10),dp(12));
        GradientDrawable bg=new GradientDrawable();bg.setColor(p.getInt("panelColor",0xff20252b));bg.setCornerRadius(dp(16));outer.setBackground(bg);outer.setAlpha(p.getInt("panelAlpha",95)/100f);panel=outer;
        TextView heading=new TextView(this);heading.setText("Панель "+(current+1)+"   ‹   ›");heading.setTextColor(Color.WHITE);heading.setGravity(Gravity.CENTER);heading.setPadding(0,dp(8),0,dp(12));heading.setOnTouchListener((v,e)->{if(e.getAction()==1){open((current+1)%p.getInt("count",3));return true;}return true;});outer.addView(heading);
        String raw=p.getString("apps"+current,"");String[] pkgs=raw.isEmpty()?new String[0]:raw.split("\\|");
        int rows=Math.max(1,(int)Math.ceil((double)Math.max(1,pkgs.length)/cols));
        for(int r=0;r<rows;r++){LinearLayout row=new LinearLayout(this);row.setOrientation(0);for(int c=0;c<cols;c++){int idx=r*cols+c;if(idx<pkgs.length)addApp(row,pkgs[idx]);else{View spacer=new View(this);row.addView(spacer,new LinearLayout.LayoutParams(0,dp(58),1));}}outer.addView(row);}
        TextView close=new TextView(this);close.setText("Закрыть");close.setTextColor(Color.WHITE);close.setGravity(Gravity.CENTER);close.setPadding(0,dp(12),0,dp(8));close.setOnClickListener(v->close());outer.addView(close);
        int width=dp(260);panelLp=new WindowManager.LayoutParams(width,WindowManager.LayoutParams.WRAP_CONTENT,overlayType(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        panelLp.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL;
        outer.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_OUTSIDE){close();return true;}if(e.getAction()==MotionEvent.ACTION_UP&&e.getRawX()<downX-dp(30)){open((current+1)%p.getInt("count",3));return true;}return true;});
        try{wm.addView(panel,panelLp);}catch(Exception ex){panel=null;}
    }
    void addApp(LinearLayout row,String pkg){
        try{android.content.pm.ApplicationInfo ai=getPackageManager().getApplicationInfo(pkg,0);LinearLayout cell=new LinearLayout(this);cell.setGravity(Gravity.CENTER);cell.setOrientation(1);TextView icon=new TextView(this);icon.setText("●");icon.setTextSize(25);icon.setTextColor(Color.WHITE);icon.setGravity(Gravity.CENTER);TextView name=new TextView(this);name.setText(getPackageManager().getApplicationLabel(ai));name.setTextColor(Color.WHITE);name.setTextSize(10);name.setGravity(Gravity.CENTER);cell.addView(icon);cell.addView(name);cell.setOnClickListener(v->{Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(launch);}close();});row.addView(cell,new LinearLayout.LayoutParams(0,dp(64),1));}catch(Exception ignored){}
    }
    void close(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}}
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){close();if(handle!=null){try{wm.removeView(handle);}catch(Exception ignored){}handle=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
